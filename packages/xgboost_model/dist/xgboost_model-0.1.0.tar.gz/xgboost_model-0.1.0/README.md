# XGBoost Model Package

This is a XGBoost Model package. Github repository can be found
[here](https://github.com/jarsushi/house-price-predict-scratch/tree/master/src/xgboost_model).

